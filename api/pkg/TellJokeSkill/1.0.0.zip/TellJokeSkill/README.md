# TellJokeSkill &middot Kenzy.Ai

The TellJokeSkill tells a random joke.

## Prompts

* Tell me a joke
* Tell me another joke
* Tell me a knock knock joke

## Example Responses

* Why was six afraid of seven? Because seven eight nine.
* Knock knock. *who's there?*  Boo.  *Boo who?*  Don't cry it's only a joke.