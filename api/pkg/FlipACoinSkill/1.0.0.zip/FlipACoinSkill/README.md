# FlipACoinSkill &middot Kenzy.Ai

The FlipACoinSkill randomly chooses between heads or tails.

## Prompts

* Flip a coin.

## Example Responses

* Heads it is!