# KnockKnockSkill &middot; Kenzy.Ai

The KnockKnockSkill enables Kenzy to appreciate a good Knock Knock joke by responding to your prompts if you have one you want to tell her.

## Prompts

* Knock Knock.

## Example Responses

* Who's there? *Boo.* Boo who? *Don't cry it's only a joke.* That's funny.