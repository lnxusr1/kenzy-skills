# WatcherSkill &middot; Kenzy.Ai

The WatcherSkill leverages any attached cameras through kenzy.image to describe what is shown in total or in part.

## Prompts

* What do you see?

## Example Responses

* I see 3 people with motion in 2 areas.
* I see motion in 3 areas.
* I don't see anything at the moment.