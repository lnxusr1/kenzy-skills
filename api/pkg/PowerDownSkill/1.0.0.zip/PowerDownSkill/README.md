# PowerDownSkill &middot Kenzy.Ai

The PowerDownSkill shuts down all of Kenzy's services.

## Prompts

* Please power down

## Example Responses

* Are you sure? *Yes.* Your wish is my command.