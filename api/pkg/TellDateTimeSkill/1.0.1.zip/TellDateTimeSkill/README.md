# TellDateTimeSkill &middot; Kenzy.Ai

The TellDateTimeSkill gives the current day, date, and/or time based on your prompt.

## Prompts

* What time is it?
* What is today's date?

## Example Responses

* It is 8:01 in the morning.
* It is Thursday, January 11.