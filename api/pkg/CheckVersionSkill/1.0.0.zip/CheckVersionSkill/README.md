# CheckVersionSkill &middot; Kenzy.Ai

The CheckVersionSkill provides the current version of the kenzy software.

## Prompts

* What is your version?

## Example Responses

* The current version is 2.0.4