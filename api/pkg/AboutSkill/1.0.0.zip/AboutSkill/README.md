# AboutSkill &middot Kenzy.Ai

The AboutSkill provides some basic information about Kenzy.

## Prompts

* How are you?
* Who are you?
* Are you real?
* Are you human?
* Who is your maker?

## Example Responses

* I am online and functioning properly.
* I am a synthetic human.  You can call me Kenzy.
* What is real?  If you define real as electrical impulses flowing through your brain then yes, I am real.
* More or less.  My maker says that I am a synthetic human.
* I was designed in twenty twenty during the Covid nineteen lockdown by linux user one.

__NOTE:__  The "How are you?" prompt will provide real-time analysis of Kenzy and all her services and provide updates if any process is running beyond anticipated parameters.