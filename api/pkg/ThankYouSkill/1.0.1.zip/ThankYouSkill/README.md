# ThankYouSkill &middot Kenzy.Ai

The ThankYouSkill will politely respond to the phrase "Thank you"

## Prompts

* Thank you
* Thanks

## Example Responses

* You're welcome
* No problem
* Anytime