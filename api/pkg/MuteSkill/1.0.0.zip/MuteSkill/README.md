# MuteSkill &middot; Kenzy.Ai

The MuteSkill enables Kenzy appropriately welcome you.

## Prompts

* Mute
* Be quiet
* Silence